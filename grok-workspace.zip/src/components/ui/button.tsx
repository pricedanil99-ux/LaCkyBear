import { cva, type VariantProps } from "class-variance-authority";
import { Slot } from "@radix-ui/react-slot";
import type { ButtonHTMLAttributes } from "react";
import { cn } from "@/lib/utils";

const buttonVariants = cva(
  "inline-flex items-center justify-center gap-2 rounded-full font-display text-sm font-semibold tracking-wide uppercase transition-transform duration-150 ease-out select-none focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-gold disabled:opacity-50 disabled:pointer-events-none active:not-disabled:scale-[0.96]",
  {
    variants: {
      variant: {
        gold: "shine bg-gradient-to-b from-gold-2 to-gold text-ink shadow-[var(--shadow-gold)] hover:brightness-105",
        cta: "shine bg-cta text-cta-ink shadow-[var(--shadow-cta)] hover:brightness-110",
        telegram: "bg-telegram text-telegram-ink hover:brightness-110",
        ghost:
          "border border-border bg-surface/70 text-fg hover:border-gold/50 hover:text-gold-2",
      },
      size: {
        md: "h-12 min-h-12 px-5",
        lg: "h-14 min-h-14 px-7 text-base",
        xl: "h-16 min-h-16 px-8 text-base",
      },
    },
    defaultVariants: {
      variant: "gold",
      size: "lg",
    },
  },
);

export function Button({
  className,
  variant,
  size,
  asChild,
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement> &
  VariantProps<typeof buttonVariants> & { asChild?: boolean }) {
  const Comp = asChild ? Slot : "button";
  return (
    <Comp className={cn(buttonVariants({ variant, size }), className)} {...props} />
  );
}
