import { SITE } from "@/lib/site";
import { PlayLink, TelegramLink } from "@/components/outbound";

export function SiteFooter() {
  return (
    <footer className="border-t border-border bg-surface/80">
      <div className="mx-auto flex max-w-6xl flex-col gap-6 px-4 py-10 sm:px-6 md:flex-row md:items-start md:justify-between">
        <div>
          <p className="font-display text-sm tracking-wide text-fg uppercase">{SITE.name}</p>
          <p className="mt-2 max-w-md text-sm leading-relaxed text-muted">
            Партнёрский промо-сайт канала {SITE.name}. Не является официальным доменом {SITE.casino}.
            Игра — на площадке по ссылке ниже.
          </p>
        </div>
        <div className="flex flex-col gap-2 text-sm">
          <PlayLink className="text-gold hover:text-gold-2">Играть в {SITE.casino}</PlayLink>
          <TelegramLink className="text-muted hover:text-fg">Telegram {SITE.name}</TelegramLink>
        </div>
      </div>
      <p className="border-t border-border px-4 py-4 text-center text-xs leading-relaxed text-muted">
        18+. Азартные игры могут вызывать зависимость. Играйте ответственно.
      </p>
    </footer>
  );
}
