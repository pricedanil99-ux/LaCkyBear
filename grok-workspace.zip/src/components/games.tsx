import { Play } from "lucide-react";
import { GAMES } from "@/lib/site";
import { PlayLink } from "@/components/outbound";

export function Games() {
  return (
    <section id="games" className="mx-auto max-w-6xl px-4 py-6 sm:px-6 sm:py-10">
      <p className="font-display text-xs tracking-[0.2em] text-gold uppercase">Каталог</p>
      <h2 className="mt-3 text-2xl text-fg">Слоты, краш, live — в один тап</h2>
      <div className="mt-8 grid grid-cols-2 gap-3 sm:grid-cols-3 sm:gap-4">
        {GAMES.map((game) => (
          <PlayLink
            key={game.id}
            className="group block rounded-xl focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-gold"
          >
            <article className="overflow-hidden rounded-xl border border-border bg-surface">
              <div className="relative aspect-[4/3] overflow-hidden bg-pine">
                <GameArt id={game.id} />
                <span className="absolute right-3 bottom-3 grid size-10 place-items-center rounded-full bg-ink/75 text-gold opacity-0 transition-opacity duration-200 group-hover:opacity-100 group-focus-visible:opacity-100">
                  <Play className="size-4 fill-current" />
                </span>
              </div>
              <div className="px-3 py-3">
                <h3 className="font-display text-sm text-fg">{game.name}</h3>
                <p className="text-xs text-muted">{game.tag}</p>
              </div>
            </article>
          </PlayLink>
        ))}
      </div>
    </section>
  );
}

function GameArt({ id }: { id: string }) {
  switch (id) {
    case "honey":
      return (
        <svg viewBox="0 0 160 120" className="h-full w-full" aria-hidden="true">
          <rect width="160" height="120" fill="#3a220c" />
          <circle cx="80" cy="62" r="36" fill="#e7c056" />
          <circle cx="80" cy="62" r="24" fill="#c47a12" />
          <circle cx="80" cy="62" r="12" fill="#f3d98a" />
          <path d="M68 28c8-16 24-16 32 0" fill="#e7c056" />
        </svg>
      );
    case "crash":
      return (
        <svg viewBox="0 0 160 120" className="h-full w-full" aria-hidden="true">
          <rect width="160" height="120" fill="#2a1010" />
          <path d="M12 100 L92 48 L148 22" fill="none" stroke="#e23b3b" strokeWidth="6" />
          <circle cx="148" cy="22" r="10" fill="#e7c056" />
          <path d="M138 22h20M148 12v20" stroke="#1a1208" strokeWidth="2" />
        </svg>
      );
    case "mines":
      return (
        <svg viewBox="0 0 160 120" className="h-full w-full" aria-hidden="true">
          <rect width="160" height="120" fill="#141a16" />
          <rect x="28" y="28" width="28" height="28" rx="6" fill="#e7c056" />
          <rect x="66" y="28" width="28" height="28" rx="6" fill="#2a1c12" />
          <rect x="104" y="28" width="28" height="28" rx="6" fill="#c47a12" />
          <rect x="28" y="66" width="28" height="28" rx="6" fill="#2a1c12" />
          <rect x="66" y="66" width="28" height="28" rx="6" fill="#e23b3b" />
          <rect x="104" y="66" width="28" height="28" rx="6" fill="#e7c056" />
        </svg>
      );
    case "wheel":
      return (
        <svg viewBox="0 0 160 120" className="h-full w-full" aria-hidden="true">
          <rect width="160" height="120" fill="#1a120c" />
          <circle cx="80" cy="62" r="40" fill="#e7c056" />
          <circle cx="80" cy="62" r="32" fill="#1a1208" />
          <path d="M80 30 A32 32 0 0 1 112 62 L80 62Z" fill="#e23b3b" />
          <path d="M80 94 A32 32 0 0 1 48 62 L80 62Z" fill="#e7c056" />
          <circle cx="80" cy="62" r="8" fill="#f3d98a" />
        </svg>
      );
    case "live":
      return (
        <svg viewBox="0 0 160 120" className="h-full w-full" aria-hidden="true">
          <rect width="160" height="120" fill="#3a1212" />
          <rect x="18" y="70" width="124" height="28" rx="14" fill="#6b1d1d" />
          <rect x="44" y="28" width="32" height="44" rx="4" fill="#f7f0e4" transform="rotate(-12 60 50)" />
          <rect x="84" y="26" width="32" height="44" rx="4" fill="#f7f0e4" transform="rotate(10 100 48)" />
          <circle cx="36" cy="84" r="8" fill="#e7c056" />
          <circle cx="56" cy="84" r="8" fill="#e7c056" />
        </svg>
      );
    default:
      return (
        <svg viewBox="0 0 160 120" className="h-full w-full" aria-hidden="true">
          <rect width="160" height="120" fill="#2a180c" />
          <circle cx="58" cy="62" r="22" fill="#e23b3b" />
          <circle cx="102" cy="62" r="22" fill="#e7c056" />
          <circle cx="80" cy="78" r="18" fill="#c47a12" />
        </svg>
      );
  }
}
