import { Gift, Sparkles, Trophy, Wallet } from "lucide-react";
import { Button } from "@/components/ui/button";
import { PlayLink } from "@/components/outbound";

const PACKS = [
  {
    icon: Gift,
    title: "Приветственный пакет",
    text: "Бонус на первый депозит и фриспины — активируются в кабинете после регистрации по ссылке.",
  },
  {
    icon: Sparkles,
    title: "Акции недели",
    text: "Турниры, кэшбек и сезонные раздачи. Свежие промо — в канале Медовик.",
  },
  {
    icon: Wallet,
    title: "Быстрый вывод",
    text: "Карты, СБП и крипта на площадке. Без лишней драмы, если аккаунт подтверждён.",
  },
  {
    icon: Trophy,
    title: "Слоты и live",
    text: "Сотни топовых игр: слоты, краш, мины, рулетка и столы с живыми дилерами.",
  },
];

export function Bonuses() {
  return (
    <section id="bonus" className="mx-auto max-w-6xl px-4 py-16 sm:px-6 sm:py-20">
      <p className="font-display text-xs tracking-[0.2em] text-gold uppercase">Почему заходят сюда</p>
      <h2 className="mt-3 max-w-2xl text-2xl text-fg">Щедрые бонусы, живая игра, выплаты без ожидания вечности</h2>
      <div className="mt-8 grid gap-4 sm:grid-cols-2">
        {PACKS.map((pack) => (
          <article
            key={pack.title}
            className="rounded-xl border border-border bg-surface p-5 sm:p-6"
          >
            <span className="grid size-11 place-items-center rounded-lg bg-gold/12 text-gold">
              <pack.icon className="size-5" />
            </span>
            <h3 className="mt-4 font-display text-lg text-fg">{pack.title}</h3>
            <p className="mt-2 text-sm leading-relaxed text-muted">{pack.text}</p>
          </article>
        ))}
      </div>
      <div className="mt-8">
        <Button variant="cta" size="xl" asChild>
          <PlayLink>Открыть Lucky Bear</PlayLink>
        </Button>
      </div>
    </section>
  );
}
