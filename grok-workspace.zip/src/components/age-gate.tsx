import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { SITE } from "@/lib/site";

const KEY = "medovik-age-ok";

export function AgeGate() {
  const [open, setOpen] = useState(true);

  useEffect(() => {
    try {
      setOpen(localStorage.getItem(KEY) !== "1");
    } catch {
      setOpen(true);
    }
  }, []);

  if (!open) return null;

  function accept() {
    try {
      localStorage.setItem(KEY, "1");
    } catch {
      /* ignore */
    }
    setOpen(false);
  }

  return (
    <div className="fixed inset-0 z-[80] flex items-center justify-center bg-bg/92 p-4">
      <div
        role="dialog"
        aria-labelledby="age-title"
        aria-modal="true"
        className="w-full max-w-md rounded-2xl border border-border bg-surface p-6 shadow-[var(--shadow-gold)] sm:p-8"
      >
        <p className="font-display text-xs tracking-[0.2em] text-gold uppercase">18+</p>
        <h2 id="age-title" className="mt-3 text-2xl text-fg">
          Только для взрослых
        </h2>
        <p className="mt-3 text-sm leading-relaxed text-muted">
          {SITE.name} — промо-вход в {SITE.casinoRu}. Азартные игры могут вызывать
          зависимость. Подтвердите, что вам есть 18 лет.
        </p>
        <div className="mt-6 flex flex-col gap-3">
          <Button type="button" variant="gold" size="lg" onClick={accept} className="w-full">
            Мне есть 18
          </Button>
          <a
            href="https://www.google.com"
            className="inline-flex h-12 min-h-12 items-center justify-center rounded-full border border-border text-sm text-muted hover:text-fg"
          >
            Уйти
          </a>
        </div>
      </div>
    </div>
  );
}
