import { createFileRoute } from "@tanstack/react-router";
import { AgeGate } from "@/components/age-gate";
import { Bonuses } from "@/components/bonuses";
import { Faq } from "@/components/faq";
import { Games } from "@/components/games";
import { Hero } from "@/components/hero";
import { SiteFooter } from "@/components/site-footer";
import { SiteHeader } from "@/components/site-header";
import { Steps } from "@/components/steps";
import { StickyCta } from "@/components/sticky-cta";
import { WinTicker } from "@/components/win-ticker";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return (
    <div className="honey-panel min-h-dvh pb-24 md:pb-0">
      <div className="site-grain" />
      <AgeGate />
      <SiteHeader />
      <main>
        <Hero />
        <WinTicker />
        <Bonuses />
        <Games />
        <Steps />
        <Faq />
      </main>
      <SiteFooter />
      <StickyCta />
    </div>
  );
}
