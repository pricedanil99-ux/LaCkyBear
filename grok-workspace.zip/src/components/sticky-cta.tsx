import { Button } from "@/components/ui/button";
import { PlayLink, TelegramLink } from "@/components/outbound";

export function StickyCta() {
  return (
    <div className="fixed inset-x-0 bottom-0 z-50 border-t border-border bg-bg/95 p-3 pb-[max(0.75rem,env(safe-area-inset-bottom))] backdrop-blur-md md:hidden">
      <div className="grid grid-cols-2 gap-2">
        <Button variant="telegram" size="md" asChild className="w-full">
          <TelegramLink>Telegram</TelegramLink>
        </Button>
        <Button variant="gold" size="md" asChild className="w-full">
          <PlayLink>Играть</PlayLink>
        </Button>
      </div>
    </div>
  );
}
