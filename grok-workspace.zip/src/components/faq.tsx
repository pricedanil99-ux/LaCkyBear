import { useState } from "react";
import { ChevronDown } from "lucide-react";
import { FAQ } from "@/lib/site";
import { cn } from "@/lib/utils";

export function Faq() {
  const [open, setOpen] = useState<number>(0);

  return (
    <section id="faq" className="mx-auto max-w-3xl px-4 py-16 sm:px-6 sm:py-20">
      <p className="font-display text-xs tracking-[0.2em] text-gold uppercase">FAQ</p>
      <h2 className="mt-3 text-2xl text-fg">Коротко по делу</h2>
      <div className="mt-8 divide-y divide-border rounded-xl border border-border bg-surface">
        {FAQ.map((item, i) => {
          const expanded = open === i;
          return (
            <div key={item.q}>
              <button
                type="button"
                className="flex w-full items-center justify-between gap-4 px-4 py-4 text-left sm:px-5"
                aria-expanded={expanded}
                onClick={() => setOpen(expanded ? -1 : i)}
              >
                <span className="font-medium text-fg">{item.q}</span>
                <ChevronDown
                  className={cn(
                    "size-5 shrink-0 text-gold transition-transform duration-200",
                    expanded && "rotate-180",
                  )}
                />
              </button>
              {expanded ? (
                <p className="px-4 pb-4 text-sm leading-relaxed text-muted sm:px-5">{item.a}</p>
              ) : null}
            </div>
          );
        })}
      </div>
    </section>
  );
}
