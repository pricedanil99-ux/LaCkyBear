export const PLAY_URL = "https://wndpr.click/r/LUCKYBEAR/JPSK77";
export const TELEGRAM_URL = "https://t.me/medovik9";

export const SITE = {
  name: "Медовик",
  casino: "Lucky Bear",
  casinoRu: "Лаки Бир",
  promo: "MEDOVIK",
  playUrl: PLAY_URL,
  telegramUrl: TELEGRAM_URL,
} as const;

export const LINK_REL = "noopener noreferrer nofollow sponsored";

export const GAMES = [
  { id: "honey", name: "Honey Spin", tag: "Слоты" },
  { id: "crash", name: "Rocket Crash", tag: "Краш" },
  { id: "mines", name: "Crystal Mines", tag: "Мины" },
  { id: "wheel", name: "Royal Wheel", tag: "Колесо" },
  { id: "live", name: "Live Night", tag: "Live" },
  { id: "fruit", name: "Night Orchard", tag: "Фрукты" },
] as const;

export const WINS = [
  { name: "Алина", game: "Honey Spin", amount: "84 600 ₽" },
  { name: "Марк", game: "Rocket Crash", amount: "126 000 ₽" },
  { name: "Катя", game: "Crystal Mines", amount: "41 250 ₽" },
  { name: "Игорь", game: "Royal Wheel", amount: "67 900 ₽" },
  { name: "Даша", game: "Live Night", amount: "210 400 ₽" },
  { name: "Тимур", game: "Night Orchard", amount: "33 150 ₽" },
  { name: "София", game: "Honey Spin", amount: "95 000 ₽" },
  { name: "Павел", game: "Rocket Crash", amount: "58 700 ₽" },
] as const;

export const FAQ = [
  {
    q: "Это официальный сайт казино?",
    a: "Нет. Это промо-вход канала Медовик: кнопки ведут на партнёрскую ссылку Lucky Bear и в Telegram. Бонусы и выплаты — уже на площадке после регистрации.",
  },
  {
    q: "Как забрать бонус?",
    a: "Нажмите «Играть», откроется Lucky Bear по партнёрской ссылке. Зарегистрируйтесь, активируйте приветственное предложение в кабинете и пополните счёт, если бонус депозитный.",
  },
  {
    q: "Можно с телефона?",
    a: "Да. Площадка открывается в браузере телефона, отдельно ничего ставить не нужно.",
  },
  {
    q: "Как быстро выводят?",
    a: "На площадке заявлены быстрые выплаты. Сроки зависят от способа и проверки аккаунта — смотрите статус заявки в кабинете Lucky Bear.",
  },
  {
    q: "Зачем Telegram?",
    a: "В канале Медовик — рабочие ссылки, акции и обновления. Если зеркало сменится, актуальный вход будет там.",
  },
] as const;
