import { WINS } from "@/lib/site";

export function WinTicker() {
  const row = [...WINS, ...WINS];

  return (
    <section className="border-y border-border bg-surface/90" aria-label="Лента выигрышей">
      <div className="overflow-hidden py-3">
        <div className="win-marquee flex w-max gap-8 pr-8">
          {row.map((win, i) => (
            <p key={`${win.name}-${i}`} className="flex items-center gap-2 text-sm whitespace-nowrap">
              <span className="text-muted">{win.name}</span>
              <span className="text-fg/70">{win.game}</span>
              <span className="font-display text-gold">{win.amount}</span>
            </p>
          ))}
        </div>
      </div>
    </section>
  );
}
