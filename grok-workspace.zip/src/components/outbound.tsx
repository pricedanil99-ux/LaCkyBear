import { forwardRef, type AnchorHTMLAttributes } from "react";
import { LINK_REL, PLAY_URL, TELEGRAM_URL } from "@/lib/site";

type Props = Omit<AnchorHTMLAttributes<HTMLAnchorElement>, "href" | "target" | "rel">;

export const Outbound = forwardRef<
  HTMLAnchorElement,
  AnchorHTMLAttributes<HTMLAnchorElement>
>(function Outbound({ className, children, ...props }, ref) {
  return (
    <a ref={ref} target="_blank" rel={LINK_REL} className={className} {...props}>
      {children}
    </a>
  );
});

export const PlayLink = forwardRef<HTMLAnchorElement, Props>(function PlayLink(
  props,
  ref,
) {
  return <Outbound ref={ref} href={PLAY_URL} {...props} />;
});

export const TelegramLink = forwardRef<HTMLAnchorElement, Props>(function TelegramLink(
  props,
  ref,
) {
  return <Outbound ref={ref} href={TELEGRAM_URL} {...props} />;
});
