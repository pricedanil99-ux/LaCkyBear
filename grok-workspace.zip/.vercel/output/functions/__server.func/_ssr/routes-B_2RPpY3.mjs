import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { v as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as Play, d as Copy, f as ChevronDown, i as Trophy, l as Menu, n as X, o as Sparkles, p as Check, r as Wallet, s as Smartphone, t as Zap, u as Gift } from "../_libs/lucide-react.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as Slot } from "../_libs/radix-ui__react-slot.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-B_2RPpY3.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 rounded-full font-display text-sm font-semibold tracking-wide uppercase transition-transform duration-150 ease-out select-none focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-gold disabled:opacity-50 disabled:pointer-events-none active:not-disabled:scale-[0.96]", {
	variants: {
		variant: {
			gold: "shine bg-gradient-to-b from-gold-2 to-gold text-ink shadow-[var(--shadow-gold)] hover:brightness-105",
			cta: "shine bg-cta text-cta-ink shadow-[var(--shadow-cta)] hover:brightness-110",
			telegram: "bg-telegram text-telegram-ink hover:brightness-110",
			ghost: "border border-border bg-surface/70 text-fg hover:border-gold/50 hover:text-gold-2"
		},
		size: {
			md: "h-12 min-h-12 px-5",
			lg: "h-14 min-h-14 px-7 text-base",
			xl: "h-16 min-h-16 px-8 text-base"
		}
	},
	defaultVariants: {
		variant: "gold",
		size: "lg"
	}
});
function Button({ className, variant, size, asChild, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size
		}), className),
		...props
	});
}
var PLAY_URL = "https://wndpr.click/r/LUCKYBEAR/JPSK77";
var TELEGRAM_URL = "https://t.me/medovik9";
var SITE = {
	name: "Медовик",
	casino: "Lucky Bear",
	casinoRu: "Лаки Бир",
	promo: "MEDOVIK",
	playUrl: PLAY_URL,
	telegramUrl: TELEGRAM_URL
};
var LINK_REL = "noopener noreferrer nofollow sponsored";
var GAMES = [
	{
		id: "honey",
		name: "Honey Spin",
		tag: "Слоты"
	},
	{
		id: "crash",
		name: "Rocket Crash",
		tag: "Краш"
	},
	{
		id: "mines",
		name: "Crystal Mines",
		tag: "Мины"
	},
	{
		id: "wheel",
		name: "Royal Wheel",
		tag: "Колесо"
	},
	{
		id: "live",
		name: "Live Night",
		tag: "Live"
	},
	{
		id: "fruit",
		name: "Night Orchard",
		tag: "Фрукты"
	}
];
var WINS = [
	{
		name: "Алина",
		game: "Honey Spin",
		amount: "84 600 ₽"
	},
	{
		name: "Марк",
		game: "Rocket Crash",
		amount: "126 000 ₽"
	},
	{
		name: "Катя",
		game: "Crystal Mines",
		amount: "41 250 ₽"
	},
	{
		name: "Игорь",
		game: "Royal Wheel",
		amount: "67 900 ₽"
	},
	{
		name: "Даша",
		game: "Live Night",
		amount: "210 400 ₽"
	},
	{
		name: "Тимур",
		game: "Night Orchard",
		amount: "33 150 ₽"
	},
	{
		name: "София",
		game: "Honey Spin",
		amount: "95 000 ₽"
	},
	{
		name: "Павел",
		game: "Rocket Crash",
		amount: "58 700 ₽"
	}
];
var FAQ = [
	{
		q: "Это официальный сайт казино?",
		a: "Нет. Это промо-вход канала Медовик: кнопки ведут на партнёрскую ссылку Lucky Bear и в Telegram. Бонусы и выплаты — уже на площадке после регистрации."
	},
	{
		q: "Как забрать бонус?",
		a: "Нажмите «Играть», откроется Lucky Bear по партнёрской ссылке. Зарегистрируйтесь, активируйте приветственное предложение в кабинете и пополните счёт, если бонус депозитный."
	},
	{
		q: "Можно с телефона?",
		a: "Да. Площадка открывается в браузере телефона, отдельно ничего ставить не нужно."
	},
	{
		q: "Как быстро выводят?",
		a: "На площадке заявлены быстрые выплаты. Сроки зависят от способа и проверки аккаунта — смотрите статус заявки в кабинете Lucky Bear."
	},
	{
		q: "Зачем Telegram?",
		a: "В канале Медовик — рабочие ссылки, акции и обновления. Если зеркало сменится, актуальный вход будет там."
	}
];
var KEY = "medovik-age-ok";
function AgeGate() {
	const [open, setOpen] = (0, import_react.useState)(true);
	(0, import_react.useEffect)(() => {
		try {
			setOpen(localStorage.getItem(KEY) !== "1");
		} catch {
			setOpen(true);
		}
	}, []);
	if (!open) return null;
	function accept() {
		try {
			localStorage.setItem(KEY, "1");
		} catch {}
		setOpen(false);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-[80] flex items-center justify-center bg-bg/92 p-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			role: "dialog",
			"aria-labelledby": "age-title",
			"aria-modal": "true",
			className: "w-full max-w-md rounded-2xl border border-border bg-surface p-6 shadow-[var(--shadow-gold)] sm:p-8",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-xs tracking-[0.2em] text-gold uppercase",
					children: "18+"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					id: "age-title",
					className: "mt-3 text-2xl text-fg",
					children: "Только для взрослых"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-3 text-sm leading-relaxed text-muted",
					children: [
						SITE.name,
						" — промо-вход в ",
						SITE.casinoRu,
						". Азартные игры могут вызывать зависимость. Подтвердите, что вам есть 18 лет."
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 flex flex-col gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "gold",
						size: "lg",
						onClick: accept,
						className: "w-full",
						children: "Мне есть 18"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "https://www.google.com",
						className: "inline-flex h-12 min-h-12 items-center justify-center rounded-full border border-border text-sm text-muted hover:text-fg",
						children: "Уйти"
					})]
				})
			]
		})
	});
}
var Outbound = (0, import_react.forwardRef)(function Outbound({ className, children, ...props }, ref) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
		ref,
		target: "_blank",
		rel: LINK_REL,
		className,
		...props,
		children
	});
});
var PlayLink = (0, import_react.forwardRef)(function PlayLink(props, ref) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outbound, {
		ref,
		href: PLAY_URL,
		...props
	});
});
var TelegramLink = (0, import_react.forwardRef)(function TelegramLink(props, ref) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outbound, {
		ref,
		href: TELEGRAM_URL,
		...props
	});
});
var PACKS = [
	{
		icon: Gift,
		title: "Приветственный пакет",
		text: "Бонус на первый депозит и фриспины — активируются в кабинете после регистрации по ссылке."
	},
	{
		icon: Sparkles,
		title: "Акции недели",
		text: "Турниры, кэшбек и сезонные раздачи. Свежие промо — в канале Медовик."
	},
	{
		icon: Wallet,
		title: "Быстрый вывод",
		text: "Карты, СБП и крипта на площадке. Без лишней драмы, если аккаунт подтверждён."
	},
	{
		icon: Trophy,
		title: "Слоты и live",
		text: "Сотни топовых игр: слоты, краш, мины, рулетка и столы с живыми дилерами."
	}
];
function Bonuses() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		id: "bonus",
		className: "mx-auto max-w-6xl px-4 py-16 sm:px-6 sm:py-20",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-xs tracking-[0.2em] text-gold uppercase",
				children: "Почему заходят сюда"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-3 max-w-2xl text-2xl text-fg",
				children: "Щедрые бонусы, живая игра, выплаты без ожидания вечности"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-8 grid gap-4 sm:grid-cols-2",
				children: PACKS.map((pack) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "rounded-xl border border-border bg-surface p-5 sm:p-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "grid size-11 place-items-center rounded-lg bg-gold/12 text-gold",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(pack.icon, { className: "size-5" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "mt-4 font-display text-lg text-fg",
							children: pack.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm leading-relaxed text-muted",
							children: pack.text
						})
					]
				}, pack.title))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-8",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "cta",
					size: "xl",
					asChild: true,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlayLink, { children: "Открыть Lucky Bear" })
				})
			})
		]
	});
}
function Faq() {
	const [open, setOpen] = (0, import_react.useState)(0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		id: "faq",
		className: "mx-auto max-w-3xl px-4 py-16 sm:px-6 sm:py-20",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-xs tracking-[0.2em] text-gold uppercase",
				children: "FAQ"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-3 text-2xl text-fg",
				children: "Коротко по делу"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-8 divide-y divide-border rounded-xl border border-border bg-surface",
				children: FAQ.map((item, i) => {
					const expanded = open === i;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "flex w-full items-center justify-between gap-4 px-4 py-4 text-left sm:px-5",
						"aria-expanded": expanded,
						onClick: () => setOpen(expanded ? -1 : i),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-medium text-fg",
							children: item.q
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: cn("size-5 shrink-0 text-gold transition-transform duration-200", expanded && "rotate-180") })]
					}), expanded ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "px-4 pb-4 text-sm leading-relaxed text-muted sm:px-5",
						children: item.a
					}) : null] }, item.q);
				})
			})
		]
	});
}
function Games() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		id: "games",
		className: "mx-auto max-w-6xl px-4 py-6 sm:px-6 sm:py-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-xs tracking-[0.2em] text-gold uppercase",
				children: "Каталог"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-3 text-2xl text-fg",
				children: "Слоты, краш, live — в один тап"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-8 grid grid-cols-2 gap-3 sm:grid-cols-3 sm:gap-4",
				children: GAMES.map((game) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlayLink, {
					className: "group block rounded-xl focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-gold",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "overflow-hidden rounded-xl border border-border bg-surface",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative aspect-[4/3] overflow-hidden bg-pine",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GameArt, { id: game.id }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "absolute right-3 bottom-3 grid size-10 place-items-center rounded-full bg-ink/75 text-gold opacity-0 transition-opacity duration-200 group-hover:opacity-100 group-focus-visible:opacity-100",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-4 fill-current" })
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "px-3 py-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "font-display text-sm text-fg",
								children: game.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted",
								children: game.tag
							})]
						})]
					})
				}, game.id))
			})
		]
	});
}
function GameArt({ id }) {
	switch (id) {
		case "honey": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
			viewBox: "0 0 160 120",
			className: "h-full w-full",
			"aria-hidden": "true",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					width: "160",
					height: "120",
					fill: "#3a220c"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "80",
					cy: "62",
					r: "36",
					fill: "#e7c056"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "80",
					cy: "62",
					r: "24",
					fill: "#c47a12"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "80",
					cy: "62",
					r: "12",
					fill: "#f3d98a"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
					d: "M68 28c8-16 24-16 32 0",
					fill: "#e7c056"
				})
			]
		});
		case "crash": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
			viewBox: "0 0 160 120",
			className: "h-full w-full",
			"aria-hidden": "true",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					width: "160",
					height: "120",
					fill: "#2a1010"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
					d: "M12 100 L92 48 L148 22",
					fill: "none",
					stroke: "#e23b3b",
					strokeWidth: "6"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "148",
					cy: "22",
					r: "10",
					fill: "#e7c056"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
					d: "M138 22h20M148 12v20",
					stroke: "#1a1208",
					strokeWidth: "2"
				})
			]
		});
		case "mines": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
			viewBox: "0 0 160 120",
			className: "h-full w-full",
			"aria-hidden": "true",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					width: "160",
					height: "120",
					fill: "#141a16"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					x: "28",
					y: "28",
					width: "28",
					height: "28",
					rx: "6",
					fill: "#e7c056"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					x: "66",
					y: "28",
					width: "28",
					height: "28",
					rx: "6",
					fill: "#2a1c12"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					x: "104",
					y: "28",
					width: "28",
					height: "28",
					rx: "6",
					fill: "#c47a12"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					x: "28",
					y: "66",
					width: "28",
					height: "28",
					rx: "6",
					fill: "#2a1c12"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					x: "66",
					y: "66",
					width: "28",
					height: "28",
					rx: "6",
					fill: "#e23b3b"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					x: "104",
					y: "66",
					width: "28",
					height: "28",
					rx: "6",
					fill: "#e7c056"
				})
			]
		});
		case "wheel": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
			viewBox: "0 0 160 120",
			className: "h-full w-full",
			"aria-hidden": "true",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					width: "160",
					height: "120",
					fill: "#1a120c"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "80",
					cy: "62",
					r: "40",
					fill: "#e7c056"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "80",
					cy: "62",
					r: "32",
					fill: "#1a1208"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
					d: "M80 30 A32 32 0 0 1 112 62 L80 62Z",
					fill: "#e23b3b"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
					d: "M80 94 A32 32 0 0 1 48 62 L80 62Z",
					fill: "#e7c056"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "80",
					cy: "62",
					r: "8",
					fill: "#f3d98a"
				})
			]
		});
		case "live": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
			viewBox: "0 0 160 120",
			className: "h-full w-full",
			"aria-hidden": "true",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					width: "160",
					height: "120",
					fill: "#3a1212"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					x: "18",
					y: "70",
					width: "124",
					height: "28",
					rx: "14",
					fill: "#6b1d1d"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					x: "44",
					y: "28",
					width: "32",
					height: "44",
					rx: "4",
					fill: "#f7f0e4",
					transform: "rotate(-12 60 50)"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					x: "84",
					y: "26",
					width: "32",
					height: "44",
					rx: "4",
					fill: "#f7f0e4",
					transform: "rotate(10 100 48)"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "36",
					cy: "84",
					r: "8",
					fill: "#e7c056"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "56",
					cy: "84",
					r: "8",
					fill: "#e7c056"
				})
			]
		});
		default: return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
			viewBox: "0 0 160 120",
			className: "h-full w-full",
			"aria-hidden": "true",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					width: "160",
					height: "120",
					fill: "#2a180c"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "58",
					cy: "62",
					r: "22",
					fill: "#e23b3b"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "102",
					cy: "62",
					r: "22",
					fill: "#e7c056"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "80",
					cy: "78",
					r: "18",
					fill: "#c47a12"
				})
			]
		});
	}
}
function Mascot({ className = "" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: `relative mx-auto w-full max-w-md ${className}`,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute top-10 left-1/2 size-64 -translate-x-1/2 rounded-full bg-gold/25 blur-3xl" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute top-16 left-1/2 size-40 -translate-x-1/2 rounded-full bg-cta/20 blur-2xl" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
				viewBox: "0 0 360 440",
				className: "mascot-float relative z-10 h-auto w-full drop-shadow-2xl",
				"aria-hidden": "true",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
						cx: "180",
						cy: "408",
						rx: "92",
						ry: "16",
						fill: "#0a0704",
						opacity: "0.55"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
						d: "M86 250c8 78 50 128 94 128s86-50 94-128c-18 22-54 34-94 34s-76-12-94-34Z",
						fill: "#c47a12"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
						cx: "180",
						cy: "268",
						rx: "86",
						ry: "96",
						fill: "#e2a43a"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
						cx: "180",
						cy: "284",
						rx: "58",
						ry: "64",
						fill: "#f3d98a"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
						d: "M74 168c-18-46 6-92 38-86 18 4 28 28 32 50-30 4-54 18-70 36Z",
						fill: "#c47a12"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
						d: "M286 168c18-46-6-92-38-86-18 4-28 28-32 50 30 4 54 18 70 36Z",
						fill: "#c47a12"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
						d: "M92 92c-10-28 8-48 26-40 8 22 10 40 8 58-14-4-26-8-34-18Z",
						fill: "#5a3310"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
						d: "M268 92c10-28-8-48-26-40-8 22-10 40-8 58 14-4 26-8 34-18Z",
						fill: "#5a3310"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
						cx: "180",
						cy: "168",
						rx: "108",
						ry: "100",
						fill: "#e7b14a"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
						cx: "180",
						cy: "188",
						rx: "70",
						ry: "58",
						fill: "#f6e1a4"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
						cx: "114",
						cy: "176",
						rx: "22",
						ry: "14",
						fill: "#ef9a9a",
						opacity: "0.55"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
						cx: "246",
						cy: "176",
						rx: "22",
						ry: "14",
						fill: "#ef9a9a",
						opacity: "0.55"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
						cx: "138",
						cy: "164",
						rx: "16",
						ry: "20",
						fill: "#1a1208"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
						cx: "222",
						cy: "164",
						rx: "16",
						ry: "20",
						fill: "#1a1208"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
						cx: "144",
						cy: "158",
						r: "5",
						fill: "#f7f0e4"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
						cx: "228",
						cy: "158",
						r: "5",
						fill: "#f7f0e4"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
						cx: "180",
						cy: "198",
						rx: "22",
						ry: "16",
						fill: "#f7f0e4"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
						cx: "180",
						cy: "200",
						rx: "12",
						ry: "9",
						fill: "#5a3310"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
						d: "M156 222c16 16 32 16 48 0",
						fill: "none",
						stroke: "#5a3310",
						strokeWidth: "6",
						strokeLinecap: "round"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
						cx: "168",
						cy: "214",
						r: "3.2",
						fill: "#c45c5c"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
						cx: "192",
						cy: "214",
						r: "3.2",
						fill: "#c45c5c"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
						cx: "78",
						cy: "300",
						rx: "28",
						ry: "22",
						fill: "#e2a43a"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
						cx: "282",
						cy: "300",
						rx: "28",
						ry: "22",
						fill: "#e2a43a"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
						cx: "78",
						cy: "300",
						r: "11",
						fill: "#f3d98a"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
						cx: "282",
						cy: "300",
						r: "11",
						fill: "#f3d98a"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
						d: "M148 92c8-28 28-46 52-46 18 0 30 10 36 26-22 6-44 10-88 20Z",
						fill: "#c47a12"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
						d: "M176 58c6-18 22-22 34-10-8 8-18 12-34 16Z",
						fill: "#8a4a12"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
						d: "M198 44c2 0 18 8 22 22 6-10 4-22-8-28-8-4-14-2-14 6Z",
						fill: "#e7c056"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
						d: "M210 40c0 0 8 18 6 32",
						fill: "none",
						stroke: "#e7c056",
						strokeWidth: "7",
						strokeLinecap: "round",
						className: "honey-drip"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
						cx: "216",
						cy: "78",
						rx: "6",
						ry: "8",
						fill: "#e7c056"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
							cx: "292",
							cy: "96",
							rx: "16",
							ry: "10",
							fill: "#f3d98a"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
							cx: "292",
							cy: "96",
							rx: "10",
							ry: "6",
							fill: "#e7c056"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
							d: "M276 96c-10-8-16-6-18 2 8 2 14 4 18 6",
							fill: "#1a1208"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
							cx: "298",
							cy: "94",
							r: "1.6",
							fill: "#1a1208"
						})
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
						cx: "96",
						cy: "250",
						r: "18",
						fill: "#e7c056",
						stroke: "#c47a12",
						strokeWidth: "3"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
						d: "M88 250h16M96 242v16",
						stroke: "#c47a12",
						strokeWidth: "2"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
						cx: "264",
						cy: "238",
						r: "14",
						fill: "#e7c056",
						stroke: "#c47a12",
						strokeWidth: "3"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
						d: "M258 238h12M264 232v12",
						stroke: "#c47a12",
						strokeWidth: "2"
					})
				]
			})
		]
	});
}
function PromoCopy() {
	const [copied, setCopied] = (0, import_react.useState)(false);
	async function copy() {
		try {
			await navigator.clipboard.writeText(SITE.promo);
			setCopied(true);
			window.setTimeout(() => setCopied(false), 1600);
		} catch {
			setCopied(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick: copy,
		className: "inline-flex h-12 min-h-12 items-center gap-2 rounded-full border border-gold/40 bg-surface px-4 text-sm text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-muted",
				children: "Промо"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-display tracking-wider text-gold",
				children: SITE.promo
			}),
			copied ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-4 text-gold" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "size-4 text-muted" })
		]
	});
}
function remaining() {
	const now = /* @__PURE__ */ new Date();
	const end = new Date(now);
	end.setHours(24, 0, 0, 0);
	const ms = Math.max(0, end.getTime() - now.getTime());
	const h = Math.floor(ms / 36e5);
	const m = Math.floor(ms % 36e5 / 6e4);
	const s = Math.floor(ms % 6e4 / 1e3);
	const pad = (n) => n.toString().padStart(2, "0");
	return `${pad(h)}:${pad(m)}:${pad(s)}`;
}
function OfferClock() {
	const [time, setTime] = (0, import_react.useState)("00:00:00");
	(0, import_react.useEffect)(() => {
		setTime(remaining());
		const id = window.setInterval(() => setTime(remaining()), 1e3);
		return () => window.clearInterval(id);
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
		className: "text-sm text-muted",
		children: [
			"Акция обновляется через",
			" ",
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-display tabular-nums text-gold",
				children: time
			})
		]
	});
}
function Hero() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		id: "top",
		className: "relative overflow-hidden",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CoinField, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative mx-auto grid max-w-6xl items-center gap-8 px-4 pt-10 pb-16 sm:px-6 lg:grid-cols-2 lg:pt-14 lg:pb-24",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "font-display text-xs tracking-[0.22em] text-gold uppercase",
					children: [
						SITE.name,
						" · вход в ",
						SITE.casinoRu
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
					className: "text-glow mt-4 text-3xl leading-[0.95] text-fg",
					children: [SITE.casino, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mt-2 block text-gold",
						children: "твой медведь удачи"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-5 max-w-xl text-base leading-relaxed text-muted sm:text-lg",
					children: [
						"Яркие эмоции, щедрые бонусы и быстрые выплаты. Сотни топовых слотов — с телефона, в один тап по партнёрской ссылке канала ",
						SITE.name,
						"."
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-7 flex flex-col gap-3 sm:flex-row",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "gold",
						size: "xl",
						asChild: true,
						className: "w-full sm:w-auto",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlayLink, { children: "Забрать бонус" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "telegram",
						size: "xl",
						asChild: true,
						className: "w-full sm:w-auto",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TelegramLink, { children: "Канал Telegram" })
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 flex flex-col gap-3 sm:flex-row sm:items-center",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PromoCopy, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OfferClock, {})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
					className: "mt-8 grid grid-cols-1 gap-3 sm:grid-cols-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							icon: Gift,
							label: "Бонусы на старт"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							icon: Zap,
							label: "Быстрые выплаты"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							icon: Smartphone,
							label: "Игра с телефона"
						})
					]
				})
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "relative mx-auto w-full max-w-xs lg:max-w-md",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mascot, {})
			})]
		})]
	});
}
function Stat({ icon: Icon, label }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
		className: "flex items-center gap-3 rounded-xl border border-border bg-surface/80 px-4 py-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "grid size-9 place-items-center rounded-full bg-gold/15 text-gold",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4" })
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-sm font-medium text-fg",
			children: label
		})]
	});
}
function CoinField() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "pointer-events-none absolute inset-0 overflow-hidden",
		"aria-hidden": "true",
		children: [
			{
				left: "8%",
				delay: "0s",
				size: "14px"
			},
			{
				left: "18%",
				delay: "1.4s",
				size: "10px"
			},
			{
				left: "28%",
				delay: "2.2s",
				size: "16px"
			},
			{
				left: "46%",
				delay: "0.6s",
				size: "12px"
			},
			{
				left: "62%",
				delay: "1.8s",
				size: "18px"
			},
			{
				left: "74%",
				delay: "0.3s",
				size: "11px"
			},
			{
				left: "88%",
				delay: "2.8s",
				size: "15px"
			}
		].map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "coin absolute top-0 rounded-full bg-gradient-to-br from-gold-2 to-amber",
			style: {
				left: c.left,
				width: c.size,
				height: c.size,
				animationDelay: c.delay
			}
		}, c.left))
	});
}
function SiteFooter() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
		className: "border-t border-border bg-surface/80",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex max-w-6xl flex-col gap-6 px-4 py-10 sm:px-6 md:flex-row md:items-start md:justify-between",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-sm tracking-wide text-fg uppercase",
				children: SITE.name
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-2 max-w-md text-sm leading-relaxed text-muted",
				children: [
					"Партнёрский промо-сайт канала ",
					SITE.name,
					". Не является официальным доменом ",
					SITE.casino,
					". Игра — на площадке по ссылке ниже."
				]
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-2 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PlayLink, {
					className: "text-gold hover:text-gold-2",
					children: ["Играть в ", SITE.casino]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TelegramLink, {
					className: "text-muted hover:text-fg",
					children: ["Telegram ", SITE.name]
				})]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "border-t border-border px-4 py-4 text-center text-xs leading-relaxed text-muted",
			children: "18+. Азартные игры могут вызывать зависимость. Играйте ответственно."
		})]
	});
}
var NAV = [
	{
		href: "#bonus",
		label: "Бонус"
	},
	{
		href: "#games",
		label: "Игры"
	},
	{
		href: "#howto",
		label: "Как войти"
	},
	{
		href: "#faq",
		label: "FAQ"
	}
];
function SiteHeader() {
	const [open, setOpen] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "sticky top-0 z-50 border-b border-border/80 bg-bg/80 backdrop-blur-md",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex h-16 max-w-6xl items-center justify-between gap-4 px-4 sm:px-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
					href: "#top",
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "grid size-9 place-items-center rounded-full bg-gold font-display text-sm text-ink",
						children: "М"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-display text-sm tracking-wide text-fg uppercase",
						children: SITE.name
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					className: "hidden items-center gap-6 text-sm text-muted md:flex",
					children: NAV.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: item.href,
						className: "hover:text-gold-2",
						children: item.label
					}, item.href))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "hidden items-center gap-2 md:flex",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "telegram",
						size: "md",
						asChild: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TelegramLink, { children: "Telegram" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "gold",
						size: "md",
						asChild: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlayLink, { children: "Играть" })
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "grid size-11 place-items-center rounded-full border border-border text-fg md:hidden",
					"aria-label": open ? "Закрыть меню" : "Открыть меню",
					onClick: () => setOpen((v) => !v),
					children: open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "size-5" })
				})
			]
		}), open ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "border-t border-border bg-surface px-4 py-4 md:hidden",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "flex flex-col gap-1",
				children: NAV.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: item.href,
					className: "flex h-12 items-center rounded-lg px-3 text-fg",
					onClick: () => setOpen(false),
					children: item.label
				}, item.href))
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 grid grid-cols-2 gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "telegram",
					size: "md",
					asChild: true,
					className: "w-full",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TelegramLink, { children: "Канал" })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "gold",
					size: "md",
					asChild: true,
					className: "w-full",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlayLink, { children: "Играть" })
				})]
			})]
		}) : null]
	});
}
var STEPS = [
	{
		n: "01",
		title: "Жми «Играть»",
		text: "Откроется Lucky Bear по партнёрской ссылке Медовик."
	},
	{
		n: "02",
		title: "Регистрируйся",
		text: "Почта, Google или Telegram — как удобнее."
	},
	{
		n: "03",
		title: "Забирай бонус",
		text: "Активируй приветственное предложение и крути слоты."
	}
];
function Steps() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		id: "howto",
		className: "mx-auto max-w-6xl px-4 py-16 sm:px-6 sm:py-20",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-xs tracking-[0.2em] text-gold uppercase",
				children: "Три шага"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-3 text-2xl text-fg",
				children: "От канала — к спину за минуту"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
				className: "mt-8 grid gap-4 md:grid-cols-3",
				children: STEPS.map((step) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "rounded-xl border border-border bg-surface p-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-gold",
							children: step.n
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "mt-3 font-display text-lg text-fg",
							children: step.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm leading-relaxed text-muted",
							children: step.text
						})
					]
				}, step.n))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8 flex flex-col gap-3 sm:flex-row",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "gold",
					size: "xl",
					asChild: true,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlayLink, { children: "Играть сейчас" })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					size: "xl",
					asChild: true,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TelegramLink, { children: "Смотреть канал" })
				})]
			})
		]
	});
}
function StickyCta() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-x-0 bottom-0 z-50 border-t border-border bg-bg/95 p-3 pb-[max(0.75rem,env(safe-area-inset-bottom))] backdrop-blur-md md:hidden",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid grid-cols-2 gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "telegram",
				size: "md",
				asChild: true,
				className: "w-full",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TelegramLink, { children: "Telegram" })
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "gold",
				size: "md",
				asChild: true,
				className: "w-full",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlayLink, { children: "Играть" })
			})]
		})
	});
}
function WinTicker() {
	const row = [...WINS, ...WINS];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "border-y border-border bg-surface/90",
		"aria-label": "Лента выигрышей",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "overflow-hidden py-3",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "win-marquee flex w-max gap-8 pr-8",
				children: row.map((win, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "flex items-center gap-2 text-sm whitespace-nowrap",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-muted",
							children: win.name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-fg/70",
							children: win.game
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-display text-gold",
							children: win.amount
						})
					]
				}, `${win.name}-${i}`))
			})
		})
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "honey-panel min-h-dvh pb-24 md:pb-0",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "site-grain" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AgeGate, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteHeader, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hero, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WinTicker, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bonuses, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Games, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Steps, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Faq, {})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteFooter, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StickyCta, {})
		]
	});
}
//#endregion
export { Home as component };
