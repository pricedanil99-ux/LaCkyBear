import { Check, Copy } from "lucide-react";
import { useState } from "react";
import { SITE } from "@/lib/site";

export function PromoCopy() {
  const [copied, setCopied] = useState(false);

  async function copy() {
    try {
      await navigator.clipboard.writeText(SITE.promo);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1600);
    } catch {
      setCopied(false);
    }
  }

  return (
    <button
      type="button"
      onClick={copy}
      className="inline-flex h-12 min-h-12 items-center gap-2 rounded-full border border-gold/40 bg-surface px-4 text-sm text-fg"
    >
      <span className="text-muted">Промо</span>
      <span className="font-display tracking-wider text-gold">{SITE.promo}</span>
      {copied ? <Check className="size-4 text-gold" /> : <Copy className="size-4 text-muted" />}
    </button>
  );
}
