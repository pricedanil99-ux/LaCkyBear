import { chromium } from "playwright";

const html = "file:///workspace/.grok/og-card.html";
const out = "/workspace/.grok/og-raw.png";

const browser = await chromium.launch({
  headless: true,
  args: ["--no-sandbox", "--disable-dev-shm-usage"],
});

try {
  const page = await browser.newPage({
    viewport: { width: 1200, height: 630 },
    deviceScaleFactor: 2,
  });
  await page.goto(html, { waitUntil: "load", timeout: 30000 });
  await page.evaluate(() => document.fonts.ready);
  await page.waitForTimeout(250);
  await page.locator("#card").screenshot({ path: out, type: "png" });
  const box = await page.locator("#card").boundingBox();
  console.log(JSON.stringify({ ok: true, out, box }));
} finally {
  await browser.close();
}
