import { Button } from "@/components/ui/button";
import { PlayLink, TelegramLink } from "@/components/outbound";

const STEPS = [
  { n: "01", title: "Жми «Играть»", text: "Откроется Lucky Bear по партнёрской ссылке Медовик." },
  { n: "02", title: "Регистрируйся", text: "Почта, Google или Telegram — как удобнее." },
  { n: "03", title: "Забирай бонус", text: "Активируй приветственное предложение и крути слоты." },
];

export function Steps() {
  return (
    <section id="howto" className="mx-auto max-w-6xl px-4 py-16 sm:px-6 sm:py-20">
      <p className="font-display text-xs tracking-[0.2em] text-gold uppercase">Три шага</p>
      <h2 className="mt-3 text-2xl text-fg">От канала — к спину за минуту</h2>
      <ol className="mt-8 grid gap-4 md:grid-cols-3">
        {STEPS.map((step) => (
          <li key={step.n} className="rounded-xl border border-border bg-surface p-5">
            <p className="font-display text-gold">{step.n}</p>
            <h3 className="mt-3 font-display text-lg text-fg">{step.title}</h3>
            <p className="mt-2 text-sm leading-relaxed text-muted">{step.text}</p>
          </li>
        ))}
      </ol>
      <div className="mt-8 flex flex-col gap-3 sm:flex-row">
        <Button variant="gold" size="xl" asChild>
          <PlayLink>Играть сейчас</PlayLink>
        </Button>
        <Button variant="ghost" size="xl" asChild>
          <TelegramLink>Смотреть канал</TelegramLink>
        </Button>
      </div>
    </section>
  );
}
