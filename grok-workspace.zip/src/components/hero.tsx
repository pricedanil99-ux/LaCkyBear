import { Gift, Smartphone, Zap } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Mascot } from "@/components/mascot";
import { PlayLink, TelegramLink } from "@/components/outbound";
import { SITE } from "@/lib/site";
import { PromoCopy } from "@/components/promo-copy";
import { OfferClock } from "@/components/offer-clock";

export function Hero() {
  return (
    <section id="top" className="relative overflow-hidden">
      <CoinField />
      <div className="relative mx-auto grid max-w-6xl items-center gap-8 px-4 pt-10 pb-16 sm:px-6 lg:grid-cols-2 lg:pt-14 lg:pb-24">
        <div>
          <p className="font-display text-xs tracking-[0.22em] text-gold uppercase">
            {SITE.name} · вход в {SITE.casinoRu}
          </p>
          <h1 className="text-glow mt-4 text-3xl leading-[0.95] text-fg">
            {SITE.casino}
            <span className="mt-2 block text-gold">твой медведь удачи</span>
          </h1>
          <p className="mt-5 max-w-xl text-base leading-relaxed text-muted sm:text-lg">
            Яркие эмоции, щедрые бонусы и быстрые выплаты. Сотни топовых слотов — с
            телефона, в один тап по партнёрской ссылке канала {SITE.name}.
          </p>

          <div className="mt-7 flex flex-col gap-3 sm:flex-row">
            <Button variant="gold" size="xl" asChild className="w-full sm:w-auto">
              <PlayLink>Забрать бонус</PlayLink>
            </Button>
            <Button variant="telegram" size="xl" asChild className="w-full sm:w-auto">
              <TelegramLink>Канал Telegram</TelegramLink>
            </Button>
          </div>

          <div className="mt-6 flex flex-col gap-3 sm:flex-row sm:items-center">
            <PromoCopy />
            <OfferClock />
          </div>

          <ul className="mt-8 grid grid-cols-1 gap-3 sm:grid-cols-3">
            <Stat icon={Gift} label="Бонусы на старт" />
            <Stat icon={Zap} label="Быстрые выплаты" />
            <Stat icon={Smartphone} label="Игра с телефона" />
          </ul>
        </div>

        <div className="relative mx-auto w-full max-w-xs lg:max-w-md">
          <Mascot />
        </div>
      </div>
    </section>
  );
}

function Stat({
  icon: Icon,
  label,
}: {
  icon: typeof Gift;
  label: string;
}) {
  return (
    <li className="flex items-center gap-3 rounded-xl border border-border bg-surface/80 px-4 py-3">
      <span className="grid size-9 place-items-center rounded-full bg-gold/15 text-gold">
        <Icon className="size-4" />
      </span>
      <span className="text-sm font-medium text-fg">{label}</span>
    </li>
  );
}

function CoinField() {
  const coins = [
    { left: "8%", delay: "0s", size: "14px" },
    { left: "18%", delay: "1.4s", size: "10px" },
    { left: "28%", delay: "2.2s", size: "16px" },
    { left: "46%", delay: "0.6s", size: "12px" },
    { left: "62%", delay: "1.8s", size: "18px" },
    { left: "74%", delay: "0.3s", size: "11px" },
    { left: "88%", delay: "2.8s", size: "15px" },
  ];

  return (
    <div className="pointer-events-none absolute inset-0 overflow-hidden" aria-hidden="true">
      {coins.map((c) => (
        <span
          key={c.left}
          className="coin absolute top-0 rounded-full bg-gradient-to-br from-gold-2 to-amber"
          style={{
            left: c.left,
            width: c.size,
            height: c.size,
            animationDelay: c.delay,
          }}
        />
      ))}
    </div>
  );
}
