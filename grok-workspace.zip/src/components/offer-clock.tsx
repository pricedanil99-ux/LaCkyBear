import { useEffect, useState } from "react";

function remaining() {
  const now = new Date();
  const end = new Date(now);
  end.setHours(24, 0, 0, 0);
  const ms = Math.max(0, end.getTime() - now.getTime());
  const h = Math.floor(ms / 3_600_000);
  const m = Math.floor((ms % 3_600_000) / 60_000);
  const s = Math.floor((ms % 60_000) / 1000);
  const pad = (n: number) => n.toString().padStart(2, "0");
  return `${pad(h)}:${pad(m)}:${pad(s)}`;
}

export function OfferClock() {
  const [time, setTime] = useState("00:00:00");

  useEffect(() => {
    setTime(remaining());
    const id = window.setInterval(() => setTime(remaining()), 1000);
    return () => window.clearInterval(id);
  }, []);

  return (
    <p className="text-sm text-muted">
      Акция обновляется через{" "}
      <span className="font-display tabular-nums text-gold">{time}</span>
    </p>
  );
}
