import { useState } from "react";
import { Menu, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { PlayLink, TelegramLink } from "@/components/outbound";
import { SITE } from "@/lib/site";

const NAV = [
  { href: "#bonus", label: "Бонус" },
  { href: "#games", label: "Игры" },
  { href: "#howto", label: "Как войти" },
  { href: "#faq", label: "FAQ" },
];

export function SiteHeader() {
  const [open, setOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50 border-b border-border/80 bg-bg/80 backdrop-blur-md">
      <div className="mx-auto flex h-16 max-w-6xl items-center justify-between gap-4 px-4 sm:px-6">
        <a href="#top" className="flex items-center gap-2">
          <span className="grid size-9 place-items-center rounded-full bg-gold font-display text-sm text-ink">
            М
          </span>
          <span className="font-display text-sm tracking-wide text-fg uppercase">
            {SITE.name}
          </span>
        </a>

        <nav className="hidden items-center gap-6 text-sm text-muted md:flex">
          {NAV.map((item) => (
            <a key={item.href} href={item.href} className="hover:text-gold-2">
              {item.label}
            </a>
          ))}
        </nav>

        <div className="hidden items-center gap-2 md:flex">
          <Button variant="telegram" size="md" asChild>
            <TelegramLink>Telegram</TelegramLink>
          </Button>
          <Button variant="gold" size="md" asChild>
            <PlayLink>Играть</PlayLink>
          </Button>
        </div>

        <button
          type="button"
          className="grid size-11 place-items-center rounded-full border border-border text-fg md:hidden"
          aria-label={open ? "Закрыть меню" : "Открыть меню"}
          onClick={() => setOpen((v) => !v)}
        >
          {open ? <X className="size-5" /> : <Menu className="size-5" />}
        </button>
      </div>

      {open ? (
        <div className="border-t border-border bg-surface px-4 py-4 md:hidden">
          <nav className="flex flex-col gap-1">
            {NAV.map((item) => (
              <a
                key={item.href}
                href={item.href}
                className="flex h-12 items-center rounded-lg px-3 text-fg"
                onClick={() => setOpen(false)}
              >
                {item.label}
              </a>
            ))}
          </nav>
          <div className="mt-3 grid grid-cols-2 gap-2">
            <Button variant="telegram" size="md" asChild className="w-full">
              <TelegramLink>Канал</TelegramLink>
            </Button>
            <Button variant="gold" size="md" asChild className="w-full">
              <PlayLink>Играть</PlayLink>
            </Button>
          </div>
        </div>
      ) : null}
    </header>
  );
}
