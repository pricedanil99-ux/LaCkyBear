export function Mascot({ className = "" }: { className?: string }) {
  return (
    <div className={`relative mx-auto w-full max-w-md ${className}`}>
      <div className="absolute top-10 left-1/2 size-64 -translate-x-1/2 rounded-full bg-gold/25 blur-3xl" />
      <div className="absolute top-16 left-1/2 size-40 -translate-x-1/2 rounded-full bg-cta/20 blur-2xl" />
      <svg
        viewBox="0 0 360 440"
        className="mascot-float relative z-10 h-auto w-full drop-shadow-2xl"
        aria-hidden="true"
      >
        <ellipse cx="180" cy="408" rx="92" ry="16" fill="#0a0704" opacity="0.55" />
        <path
          d="M86 250c8 78 50 128 94 128s86-50 94-128c-18 22-54 34-94 34s-76-12-94-34Z"
          fill="#c47a12"
        />
        <ellipse cx="180" cy="268" rx="86" ry="96" fill="#e2a43a" />
        <ellipse cx="180" cy="284" rx="58" ry="64" fill="#f3d98a" />
        <path
          d="M74 168c-18-46 6-92 38-86 18 4 28 28 32 50-30 4-54 18-70 36Z"
          fill="#c47a12"
        />
        <path
          d="M286 168c18-46-6-92-38-86-18 4-28 28-32 50 30 4 54 18 70 36Z"
          fill="#c47a12"
        />
        <path d="M92 92c-10-28 8-48 26-40 8 22 10 40 8 58-14-4-26-8-34-18Z" fill="#5a3310" />
        <path d="M268 92c10-28-8-48-26-40-8 22-10 40-8 58 14-4 26-8 34-18Z" fill="#5a3310" />
        <ellipse cx="180" cy="168" rx="108" ry="100" fill="#e7b14a" />
        <ellipse cx="180" cy="188" rx="70" ry="58" fill="#f6e1a4" />
        <ellipse cx="114" cy="176" rx="22" ry="14" fill="#ef9a9a" opacity="0.55" />
        <ellipse cx="246" cy="176" rx="22" ry="14" fill="#ef9a9a" opacity="0.55" />
        <ellipse cx="138" cy="164" rx="16" ry="20" fill="#1a1208" />
        <ellipse cx="222" cy="164" rx="16" ry="20" fill="#1a1208" />
        <circle cx="144" cy="158" r="5" fill="#f7f0e4" />
        <circle cx="228" cy="158" r="5" fill="#f7f0e4" />
        <ellipse cx="180" cy="198" rx="22" ry="16" fill="#f7f0e4" />
        <ellipse cx="180" cy="200" rx="12" ry="9" fill="#5a3310" />
        <path
          d="M156 222c16 16 32 16 48 0"
          fill="none"
          stroke="#5a3310"
          strokeWidth="6"
          strokeLinecap="round"
        />
        <circle cx="168" cy="214" r="3.2" fill="#c45c5c" />
        <circle cx="192" cy="214" r="3.2" fill="#c45c5c" />
        <ellipse cx="78" cy="300" rx="28" ry="22" fill="#e2a43a" />
        <ellipse cx="282" cy="300" rx="28" ry="22" fill="#e2a43a" />
        <circle cx="78" cy="300" r="11" fill="#f3d98a" />
        <circle cx="282" cy="300" r="11" fill="#f3d98a" />
        <path
          d="M148 92c8-28 28-46 52-46 18 0 30 10 36 26-22 6-44 10-88 20Z"
          fill="#c47a12"
        />
        <path d="M176 58c6-18 22-22 34-10-8 8-18 12-34 16Z" fill="#8a4a12" />
        <path d="M198 44c2 0 18 8 22 22 6-10 4-22-8-28-8-4-14-2-14 6Z" fill="#e7c056" />
        <path
          d="M210 40c0 0 8 18 6 32"
          fill="none"
          stroke="#e7c056"
          strokeWidth="7"
          strokeLinecap="round"
          className="honey-drip"
        />
        <ellipse cx="216" cy="78" rx="6" ry="8" fill="#e7c056" />
        <g>
          <ellipse cx="292" cy="96" rx="16" ry="10" fill="#f3d98a" />
          <ellipse cx="292" cy="96" rx="10" ry="6" fill="#e7c056" />
          <path d="M276 96c-10-8-16-6-18 2 8 2 14 4 18 6" fill="#1a1208" />
          <circle cx="298" cy="94" r="1.6" fill="#1a1208" />
        </g>
        <circle cx="96" cy="250" r="18" fill="#e7c056" stroke="#c47a12" strokeWidth="3" />
        <path d="M88 250h16M96 242v16" stroke="#c47a12" strokeWidth="2" />
        <circle cx="264" cy="238" r="14" fill="#e7c056" stroke="#c47a12" strokeWidth="3" />
        <path d="M258 238h12M264 232v12" stroke="#c47a12" strokeWidth="2" />
      </svg>
    </div>
  );
}
