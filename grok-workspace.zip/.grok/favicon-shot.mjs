import { chromium } from "playwright";
import { writeFileSync } from "node:fs";

const svg = `file:///workspace/public/favicon.svg`;
const browser = await chromium.launch({
  headless: true,
  args: ["--no-sandbox", "--disable-dev-shm-usage"],
});
try {
  for (const size of [16, 32, 64]) {
    const page = await browser.newPage({
      viewport: { width: size, height: size },
      deviceScaleFactor: 1,
    });
    await page.setContent(
      `<html><body style="margin:0;background:#111">
         <img src="${svg}" width="${size}" height="${size}" style="display:block"/>
       </body></html>`,
      { waitUntil: "load" },
    );
    await page.locator("img").screenshot({
      path: `/workspace/.grok/favicon-${size}.png`,
      type: "png",
    });
    await page.close();
  }
  console.log("ok");
} finally {
  await browser.close();
}
