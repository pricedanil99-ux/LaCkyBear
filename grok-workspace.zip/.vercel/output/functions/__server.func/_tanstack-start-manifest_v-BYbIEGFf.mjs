//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BYbIEGFf.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-DL-Tc5Gn.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DL-Tc5Gn.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-Ch6dhPpd.js"]
	}
} });
//#endregion
export { tsrStartManifest };
